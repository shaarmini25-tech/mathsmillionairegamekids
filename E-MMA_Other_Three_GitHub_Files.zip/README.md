# Math Millionaire Arena (E-MMA)

Math Millionaire Arena is an interactive quiz website for primary school pupils.  
The game includes 15 questions, four answer choices, a prize ladder, sound effects, immediate feedback, an AI Hint button, and a final winner screen.

## Required Files

Place these files together in the root of the GitHub repository:

```text
index.html
style.css
script.js
README.md
```

## How to Upload to GitHub

1. Log in to GitHub.
2. Create a new public repository.
3. Click **Add file → Upload files**.
4. Upload:
   - `index.html`
   - `style.css`
   - `script.js`
   - `README.md`
5. Click **Commit changes**.

## Enable GitHub Pages

1. Open **Settings**.
2. Select **Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select:
   - Branch: `main`
   - Folder: `/(root)`
5. Click **Save**.
6. Wait a few minutes for the website to be published.

Your link will use this format:

```text
https://YOUR-USERNAME.github.io/REPOSITORY-NAME/
```

## How Teachers Can Change the Questions

Open `script.js` and find:

```javascript
const questions = [
```

Each question uses this format:

```javascript
{
  question: "6 + 3 = ?",
  answers: ["8", "9", "10", "7"],
  correct: 1,
  hint: "Start from 6 and count 3 more.",
  explanation: "6 + 3 = 9."
}
```

### Correct Answer Number

```text
0 = A
1 = B
2 = C
3 = D
```

Teachers may replace the question, answer choices, correct answer, hint, and explanation with content from Mathematics, Science, English, Bahasa Melayu, History, Geography, or other subjects.

## Important

- Keep the file names exactly as written.
- Do not rename `index.html`.
- Keep all files in the repository root.
- Use commas correctly between question blocks.
- After editing, click **Commit changes** and wait for GitHub Pages to update.
